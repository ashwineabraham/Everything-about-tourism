<head>
    <script>
	function CenterWindow(windowWidth, windowHeight, windowOuterHeight, url, wname, features) {
            var centerLeft = parseInt((window.screen.availWidth - windowWidth) / 2);
            var centerTop = parseInt(((window.screen.availHeight - windowHeight) / 2) - windowOuterHeight);

            var misc_features;
            if (features) {
                misc_features = ', ' + features;
            }
            else {
                misc_features = ', status=no, location=no, scrollbars=yes, resizable=no';
            }
            var windowFeatures = 'width=' + windowWidth + ',height=' + windowHeight + ',left=' + centerLeft + ',top=' + centerTop + misc_features;
            var win = window.open(url, wname, windowFeatures);
            win.focus();
            return win;
	}
    </script>
    <style>
        * {
            font-family: helvetica;
        }
    </style>
</head>

<body>

<table cellpadding="10">
	<tr>
		<td valign="top">
<?php

// connect to the database
	include ("dbconnect.php");

// create a form
	echo ("<form name=\"select_type\" method=\"POST\" action=\"all_providers.php\">"); 

// start a SELECT dropdown option with an onchange trigger
	echo ("<select NAME=\"sitekey\" size=\"1\" id=\"sitekey\" onchange=\"this.form.submit()\">");
	echo ("<option value=\"\">Choose a site</option>");

// grab a list of the unique SITEKEY variables ordered alphabetically
	$query="select distinct(sitekey) as sitekey from provider where sitekey != '' order by sitekey asc;";
	$result=mysql_query($query);
	while ($row = mysql_fetch_array($result)) {
		
// create an option for each
		echo ("<option value=\"".$row["sitekey"]."\"");
		
// check to see which one is currently selected and make that the default
		if ($_POST["sitekey"]==$row["sitekey"]){
			echo (" selected");
		}
	
		echo (">".$row["sitekey"]."</option>\n");
	}
	echo ("</select>");

// close the form
	echo ("</form>");

?>
<!--			<a name="start"></a>
			<a href="#a">a</a><br>
			<a href="#b">b</a><br>
			<a href="#c">c</a><br>
			<a href="#d">d</a><br>
			<a href="#e">e</a><br>
			<a href="#f">f</a><br>
			<a href="#g">g</a><br>
			<a href="#h">h</a><br>
			<a href="#i">i</a><br> -->
			
		</td><td valign="top">

<?php

// create a counter
	$counter=0;
	
// get an alphabetical list of all businesses in this SITEKEY
//	$query="select distinct(providername) as providername from provider where sitekey = '".$_POST["sitekey"]."' order by sitekey asc;";
	$query="select providerid, providername from provider where sitekey = '".$_POST["sitekey"]."' group by providername;";
	$result=mysql_query($query);
	while ($row = mysql_fetch_array($result)) {

// check if the returned business name is only numbers and if so disregard it
		if (!ctype_digit($row["providername"])){
			
// get the first letter of the business name 
			$firstchar=$row["providername"][0];
			
// make it uppercase as some are lowercase and this throws the detector below
			$firstchar=strtoupper($firstchar);
			
// if the current starting letter os different to the previous then..
			if ($firstchar!==$lastchar){
				
// add a paragraph and an anchor to suit
				echo ("<p><a name=\"".$firstchar."\"><a href=\"#start\">Back to the start</a><p>");
			}
			
// truncate the really long names
			$providername= (strlen($row["providername"]) > 30) ? substr($row["providername"],0,27).'...' : $row["providername"];

// if it passes the mixed character test then write it out
			echo ("<a href=\"javascript:void(0)\" onclick=\"CenterWindow(500,400,50,'edit_provider.php?provider_id=".$row["providerid"]."','Provider Details');\"><img src=\"images/notebook--pencil.png\" border=\"0\" title=\"Edit ".$row["providername"]."\"></a> ".$providername."<br>\n");
			
// increment the counter
			$counter++;
			
			$lastchar=$firstchar;
		}
		
// if the counter has reached 30
		if ($counter===30){
			
// if so then start a new column
			echo ("<img src=\"images/trans.gif\" width=\"250\" height=\"1\"></td><td valign=\"top\" width=\"250\">");
			
// reset the counter to zero
			$counter=0;
		}
	}

?>

		<img src="images/trans.gif" width="250" height="1"></td>
	</tr>
</table>
</body>