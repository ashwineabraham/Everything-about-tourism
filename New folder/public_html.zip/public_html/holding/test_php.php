<?php
    date_default_timezone_set ("Australia/Hobart");
this_is_a_test_error();
phpinfo();
?>