<body>
	<center>
		<table cellpadding="10" cellspacing="10" border="1">
			<tr>
				<td colspan="5"><center>Welcome to the Everything About family!</td>
			</tr>
			<tr>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=4x4">4X4</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=adventure">Adventure</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=advertising">Advertising</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=collectibles">Collectibles</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=disability">Disability</a></td>
			</tr>
			<tr>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=education">Education</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=events">Events</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=finance">Finance</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=financedirectory">Finance Directory</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=health">Health</a></td>
			</tr>
			<tr>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=hunting">Hunting</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=relationships">Relationships</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=sunglasses">Sunglasses</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=tourism">Tourism</a></td>
				<td width="100" height="50" align="center" valign="middle"><a target="_top" href="index.php?site=weddings">Weddings</a></td>
			</tr>
		</table>
	</center>
</body>				
