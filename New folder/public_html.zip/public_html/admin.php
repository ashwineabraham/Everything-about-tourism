<head>
<style type="text/css">
    body{
        margin: 0;
        padding: 0;
   		background:url('world-map.gif') center center no-repeat;
    }
</style>

<body>

	<table width="100%" height="100%">
		<tr>
			<td height="100%" width="100%"></td>
		</tr>
	</table>

</body>