<?php

    header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
    header('Pragma: no-cache'); // HTTP 1.0.
    header('Expires: 0'); // Proxies.

?>

<frameset>
    <frameset rows="29,*" frameborder="0" framespacing="0" border="0">
        <frame name="MENU" src="menu.php" frameborder="0">
        <frame name="ADMIN" src="admin.php" frameborder="0">
    </frameset>
<frameset>        