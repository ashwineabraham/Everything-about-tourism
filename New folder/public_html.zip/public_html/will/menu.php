<?php

// totally stop browsers from caching the contents of this page
    header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
    header('Pragma: no-cache'); // HTTP 1.0.
    header('Expires: 0'); // Proxies.

?>

<head>
    
    <style type="text/css">
        body{
            margin: 0;
            padding: 0
        }
    </style>
    
    <script type="text/javascript" src="stmenu.js"></script>

</head>

<body bgcolor="#C1CDCD">
    <script type="text/javascript" src="menu.js"></script>
</body>