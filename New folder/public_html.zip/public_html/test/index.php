<head>
	<style type="text/css">
		body{
			margin: 0;
			padding: 0
		}
	</style>
</head>
<body>
	<table width="100%" height="100%" cellpadding="0" cellspacing="0">
		<tr>
			<td background="images/top_bg.gif"><img src="images/trans.gif" width="1" height="186"></td>
			<td background="images/top_bg.gif" valign="middle"><center><img src="images/title.gif"></center></td>
			<td background="images/top_bg.gif"></td>
		</tr>
		<tr>
			<td colspan="3" bgcolor="#003333"><img src="images/trans.gif" width="1" height="1"></td>
		</tr>
		<tr>
			<td height="100%" colspan="3" valign="top" background="images/blue_bg.jpg">

				<table cellpadding="0" cellspacing="0" width="100%" height="100%">
					<tr>
						<td><img src="images/trans.gif" width="1" height="10"></td>
					</tr>
					<tr>
						<td valign="top"><center><img src="images/menu.png"></center></td>
					</tr>
					<tr>
						<td><img src="images/trans.gif" width="1" height="10"></td>
					</tr>
					<tr>
						<td><center><img src="images/list.png"></center></td>
					</tr>
					<tr>
						<td><center><img src="images/footer.gif"></center></td>
					</tr>
					
					<tr>
						<td><center><img src="images/advert1.jpg"></center></td>
					</tr>
					
				</table>

			</td>
		</tr>
	</table>
</body>